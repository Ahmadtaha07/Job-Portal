<ul class="nav navbar-nav navbar-right">
  


 <li><a href="reg.php"><span class="glyphicon glyphicon-on" aria-hidden="true"></span> Log In</a></li>
 <li><a href="sign-up.php"><span class="glyphicon glyphicon-on" aria-hidden="true"></span> Sign Up</a></li>
 </ul>
 <form class="navbar-form navbar-right" action="#" method="GET">
 <div class="input-group">
 <input type="text" class="form-control" placeholder="Search..." id="query" name="search" value="">
 <div class="input-group-btn">
 <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-search"></span></button>
 </div>
 </div>
 </form>
 </div>