# online-job-portal-in-php

Online Jop Portal Features
Administrator
Job Seeker
Job Provider
Job Search
System Users
Administrator
Job Seeker
Job Provider
ADMINISTRATOR FEATURES
Administrator can manage whole website:

Manage complete jobseeker section. Like: activate/deactivate/delete/ edit jobseeker’s information.
Admin user can view the jobseeker’s applications for each job.
Manage complete employer section. Admin user can activate/deactivate/delete/ edit company information.
Manage posted jobs. Like: activate/deactivate/delete/edit posted job.
Manage whole website content. Dynamic CMS is included to manage the content of the website.
Admin user can send message to any jobseeker or job provider.
Admin user can send bulk emails as well.
Admin user can manage the skills section. Like: Add or remove skills from the website.
Manage newsletters section
Manage success stories
Admin user can manage and handle the prohibited words for whole website.
Admin user can add/edit countries, cities, salaries range, qualification, institutes, job industries, website ads.
JOB PROVIDER / COMPANY FEATURES
After registration job provider can perform following action:

 
Add / Edit company’s profile
Post new job vacancies
Edit / Deactivate posted jobs
Job provider can see the list of jobseekers who has applied for the job
Job provider can search jobseekers
Job provider can see and download the jobseeker’s resume
Job provider can send message to any job seeker
JOB SEEKER FEATURES
After registration job seeker can perform following actions:

Search for jobs
Apply Online for desire job
Add/Edit profile information including qualification, experience, and skills.
Build his resume by using CV builder functionality of the website.
Upload latest resume.
MAIN WEBSITE(WEBSITE FONT END)
From main website, user can perform following actions:

Search jobs on the basis of skills, city, country or job title
Register as a jobseeker or as a job provider
Login to jobseeker or job provider portal
About Us
Contact us
Recent Jobs

visit for more https://projectworlds.in
